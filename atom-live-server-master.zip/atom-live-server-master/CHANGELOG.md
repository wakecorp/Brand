## 2.0.0

#### New features
* Live server can be stopped.
* Support `.atom-live-server.json`.

#### Breaking changes
* Keymaps changed
