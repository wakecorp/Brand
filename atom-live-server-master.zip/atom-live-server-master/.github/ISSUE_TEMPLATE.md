If you have a problem launching a live-server, please try following steps:

1. Make sure you use the right hotkeys. After v2.0.0, the keys became `ctrl-alt` combination.
2. Try launching live-server from top menu: `Package -> live-server -> Start Server` to see if it works.
