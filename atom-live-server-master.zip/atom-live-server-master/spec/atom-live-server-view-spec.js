'use babel';

import AtomLiveServerView from '../lib/atom-live-server-view';

describe('AtomLiveServerView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
